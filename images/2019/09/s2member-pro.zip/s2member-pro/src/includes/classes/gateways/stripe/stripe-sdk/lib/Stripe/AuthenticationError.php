<?php
// @codingStandardsIgnoreFile

class Stripe_AuthenticationError extends Stripe_Error
{
}
