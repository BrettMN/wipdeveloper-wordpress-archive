<?php
// @codingStandardsIgnoreFile

class Stripe_ApiError extends Stripe_Error
{
}
