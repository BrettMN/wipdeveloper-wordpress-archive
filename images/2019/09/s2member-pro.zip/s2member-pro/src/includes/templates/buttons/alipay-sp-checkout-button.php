<?php
// @codingStandardsIgnoreFile
if(!defined('WPINC')) // MUST have WordPress.
	exit ("Do not access this file directly.");
?>

<a href="%%url%%">
 <img src="%%images%%/alipay-button.gif" style="width:auto; height:auto; border:0;" alt="AliPay" />
</a>
