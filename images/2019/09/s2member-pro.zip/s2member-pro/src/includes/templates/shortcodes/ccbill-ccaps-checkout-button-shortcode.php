<?php
// @codingStandardsIgnoreFile
if(!defined('WPINC')) // MUST have WordPress.
	exit("Do not access this file directly.");
?>

[s2Member-Pro-ccBill-Button level="*" ccaps="music,videos" desc="<?php echo esc_attr (_x ("Description and pricing details here.", "s2member-admin", "s2member")); ?>" cc="USD" custom="%%custom%%" ra="2.95" rp="1" rt="L" rr="0" image="default" output="anchor" /]
