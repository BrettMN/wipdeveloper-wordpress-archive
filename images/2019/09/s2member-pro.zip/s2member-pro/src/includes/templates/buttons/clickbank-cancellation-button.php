<?php
// @codingStandardsIgnoreFile
if(!defined('WPINC')) // MUST have WordPress.
	exit ("Do not access this file directly.");
?>

<a href="http://www.clickbank.com/orderDetail.htm">
 <img src="%%images%%/clickbank-edit-button.png" style="width:auto; height:auto; border:0;" alt="ClickBank" />
</a>
