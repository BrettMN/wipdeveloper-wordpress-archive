<?php
// @codingStandardsIgnoreFile
if(!defined('WPINC')) // MUST have WordPress.
	exit("Do not access this file directly.");
?>

<option value="0-D" selected="selected"><?php echo esc_html (_x ("No Trial", "s2member-admin", "s2member")); ?></option>
<option value="3-D"><?php echo esc_html (_x ("3 Days", "s2member-admin", "s2member")); ?></option>
<option value="4-D"><?php echo esc_html (_x ("4 Days", "s2member-admin", "s2member")); ?></option>
<option value="5-D"><?php echo esc_html (_x ("5 Days", "s2member-admin", "s2member")); ?></option>
<option value="6-D"><?php echo esc_html (_x ("6 Days", "s2member-admin", "s2member")); ?></option>
<option value="7-D"><?php echo esc_html (_x ("7 Days", "s2member-admin", "s2member")); ?></option>
<option value="8-D"><?php echo esc_html (_x ("8 Days", "s2member-admin", "s2member")); ?></option>
<option value="9-D"><?php echo esc_html (_x ("9 Days", "s2member-admin", "s2member")); ?></option>
<option value="10-D"><?php echo esc_html (_x ("10 Days", "s2member-admin", "s2member")); ?></option>
<option value="11-D"><?php echo esc_html (_x ("11 Days", "s2member-admin", "s2member")); ?></option>
<option value="12-D"><?php echo esc_html (_x ("12 Days", "s2member-admin", "s2member")); ?></option>
<option value="13-D"><?php echo esc_html (_x ("13 Days", "s2member-admin", "s2member")); ?></option>
<option value="14-D"><?php echo esc_html (_x ("14 Days", "s2member-admin", "s2member")); ?></option>
<option value="15-D"><?php echo esc_html (_x ("15 Days", "s2member-admin", "s2member")); ?></option>
<option value="16-D"><?php echo esc_html (_x ("16 Days", "s2member-admin", "s2member")); ?></option>
<option value="17-D"><?php echo esc_html (_x ("17 Days", "s2member-admin", "s2member")); ?></option>
<option value="18-D"><?php echo esc_html (_x ("18 Days", "s2member-admin", "s2member")); ?></option>
<option value="19-D"><?php echo esc_html (_x ("19 Days", "s2member-admin", "s2member")); ?></option>
<option value="20-D"><?php echo esc_html (_x ("20 Days", "s2member-admin", "s2member")); ?></option>
<option value="21-D"><?php echo esc_html (_x ("21 Days", "s2member-admin", "s2member")); ?></option>
<option value="22-D"><?php echo esc_html (_x ("22 Days", "s2member-admin", "s2member")); ?></option>
<option value="23-D"><?php echo esc_html (_x ("23 Days", "s2member-admin", "s2member")); ?></option>
<option value="24-D"><?php echo esc_html (_x ("24 Days", "s2member-admin", "s2member")); ?></option>
<option value="25-D"><?php echo esc_html (_x ("25 Days", "s2member-admin", "s2member")); ?></option>
<option value="26-D"><?php echo esc_html (_x ("26 Days", "s2member-admin", "s2member")); ?></option>
<option value="27-D"><?php echo esc_html (_x ("27 Days", "s2member-admin", "s2member")); ?></option>
<option value="28-D"><?php echo esc_html (_x ("28 Days", "s2member-admin", "s2member")); ?></option>
<option value="29-D"><?php echo esc_html (_x ("29 Days", "s2member-admin", "s2member")); ?></option>
<option value="30-D"><?php echo esc_html (_x ("30 Days", "s2member-admin", "s2member")); ?></option>
<option value="31-D"><?php echo esc_html (_x ("31 Days", "s2member-admin", "s2member")); ?></option>
